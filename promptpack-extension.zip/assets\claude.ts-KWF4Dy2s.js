import{m as Z,s as ee,q as E,n as z,o as te}from"./theme-COKq0XYb.js";import{E as ne}from"./db-3tdwsUDZ.js";import"./api-BDkNmw7T.js";const oe=200,re=64,W=`
  <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path d="M9 3l1.5 4.5L15 9l-4.5 1.5L9 15l-1.5-4.5L3 9l4.5-1.5L9 3z"></path>
    <path d="M18 3l1 2.5L21.5 6l-2.5 1L18 9.5l-1-2.5L14.5 6l2.5-1L18 3z"></path>
  </svg>
`,ie=`
  <svg class="pp-spin" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true">
    <circle cx="12" cy="12" r="9" stroke-dasharray="42" stroke-dashoffset="12"></circle>
  </svg>
`;function d(e,t="success"){let n=document.getElementById("pp-toast");n||(n=document.createElement("div"),n.id="pp-toast",n.style.cssText=`
      position: absolute;
      z-index: 1000001;
      padding: 10px 12px;
      border-radius: 8px;
      color: white;
      font-size: 13px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.25);
      opacity: 0;
      transform: translateY(6px);
      transition: opacity 140ms ease, transform 140ms ease;
      font-family: ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Arial;
      pointer-events: none;
    `,document.body.appendChild(n)),n.style.background=t==="error"?"rgba(220, 38, 38, 0.92)":"rgba(59, 130, 246, 0.92)";const i=k();if(i){const o=i.getBoundingClientRect(),r=200,c=80;n.style.position="fixed",n.style.left=`${o.right+c}px`,n.style.top=`${o.top}px`,o.right+c+r>window.innerWidth&&(n.style.left=`${o.left-r-c}px`)}else n.style.position="fixed",n.style.right="16px",n.style.bottom="140px";n.textContent=e,n.style.opacity="1",n.style.transform="translateY(0)",window.setTimeout(()=>{n.style.opacity="0",n.style.transform="translateY(6px)"},1400)}function $(e){const t=e.getBoundingClientRect(),n=window.getComputedStyle(e);return t.width>10&&t.height>10&&n.display!=="none"&&n.visibility!=="hidden"&&n.opacity!=="0"}function k(){const e=document.querySelector('[contenteditable="true"][data-placeholder], div[contenteditable="true"].ProseMirror');if(e&&$(e))return e;const t=o=>{let r=o.parentElement,c=0;for(;r&&c<20;){const l=r.getAttribute("role"),p=r.getAttribute("aria-modal");if(l==="dialog"||p==="true"||r.classList.contains("modal")||r.classList.contains("settings"))return!1;if(r.tagName==="FORM"){const h=r.className.toLowerCase();if(h.includes("setting")||h.includes("preference"))return!1}r=r.parentElement,c++}if(o instanceof HTMLTextAreaElement){const l=o.placeholder.toLowerCase();if(l.includes("additional behavior")||l.includes("preference")||l.includes("custom instruction"))return!1}return!0},n=Array.from(document.querySelectorAll('[contenteditable="true"]')).filter($).filter(t);if(n.length)return n.sort((o,r)=>r.clientWidth*r.clientHeight-o.clientWidth*o.clientHeight),n[0];const i=Array.from(document.querySelectorAll("textarea")).filter($).filter(t);return i.length?(i.sort((o,r)=>r.clientWidth*r.clientHeight-o.clientWidth*o.clientHeight),i[0]):null}function F(e){return e instanceof HTMLTextAreaElement?e.value??"":e.innerText??""}function se(e,t){if(e instanceof HTMLTextAreaElement){const n=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value")?.set;n?n.call(e,t):e.value=t,e.dispatchEvent(new InputEvent("input",{bubbles:!0,inputType:"insertText",data:t}));return}e.textContent=t,e.dispatchEvent(new InputEvent("input",{bubbles:!0,inputType:"insertText",data:t}))}function ae(e){e.style.right=`${oe}px`,e.style.bottom=`${re}px`,e.style.left="auto",e.style.top="auto"}function ce(){if(document.getElementById("pp-enhance-styles"))return;const e=document.createElement("style");e.id="pp-enhance-styles",e.textContent=`
    @keyframes pp-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
    .pp-spin { animation: pp-spin 0.9s linear infinite; }

    /* Claude dropdown styling with orange theme */
    #pp-enhance-mode option {
      background: #C15F3C;
      color: #ffffff;
    }
    #pp-enhance-mode:focus {
      outline: 2px solid rgba(193, 95, 60, 0.5);
      outline-offset: 2px;
    }
  `,document.head.appendChild(e)}function le(e,t){const n=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="none" stroke="${t}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5.5 7.5l4.5 4.5 4.5-4.5"/></svg>`;e.style.setProperty("appearance","none"),e.style.setProperty("-webkit-appearance","none"),e.style.backgroundImage=`url("data:image/svg+xml;utf8,${encodeURIComponent(n)}")`,e.style.backgroundRepeat="no-repeat",e.style.backgroundPosition="right 6px center",e.style.backgroundSize="10px 10px",e.style.paddingRight="22px"}function Y(e){const t=e==="dark"?E.dark:E.light,n=document.getElementById("pp-enhance-wrap");n&&(n.style.background=t.accent,n.style.border="none",n.style.boxShadow=t.shadow,n.style.borderRadius="6px",n.style.fontFamily=t.font,n.style.backdropFilter="none",n.style.webkitBackdropFilter="none");const i=document.getElementById("pp-save-btn");i&&(i.style.background="transparent",i.style.border="none",i.style.color="#ffffff",i.style.fontFamily=t.font,i.style.borderRadius="6px");const o=document.getElementById("pp-enhance-btn");o&&(o.style.background="transparent",o.style.border="none",o.style.color="#ffffff",o.style.fontFamily=t.font,o.style.borderRadius="6px");const r=document.getElementById("pp-enhance-mode");r&&(r.style.background="transparent",r.style.border="none",r.style.color="#ffffff",r.style.fontFamily=t.font,le(r,"#ffffff"));const c=document.getElementById("pp-enhance-status");c&&(c.style.color=t.text)}let w=null,x=Z(),O=location.href,R=!1,U=null,H=new Set,P="structured",q=!1,A=!1;function de(){const e=document.getElementById("pp-enhance-wrap");return e&&document.body.contains(e)?e:null}async function pe(){return chrome?.runtime?.sendMessage?new Promise(e=>{chrome.runtime.sendMessage({type:"PP_GET_ENHANCE_TOKEN"},t=>{if(chrome.runtime.lastError){e(null);return}const n=t?.token;e(typeof n=="string"?n:null)})}):null}function _(e){A=e;const t=document.getElementById("pp-save-btn"),n=document.getElementById("pp-enhance-btn"),i=!e||q;t&&(t.disabled=i,t.style.opacity=i?"0.6":"1",t.style.cursor=i?"not-allowed":"pointer"),n&&(n.disabled=i,n.style.opacity=i?"0.6":"1",n.style.cursor=i?"not-allowed":"pointer")}function D(e){q=e;const t=document.getElementById("pp-enhance-btn"),n=document.getElementById("pp-save-btn"),i=document.getElementById("pp-enhance-status"),o=document.getElementById("pp-enhance-mode");t&&(t.innerHTML=e?ie:W,t.setAttribute("aria-busy",e?"true":"false"),t.title=e?"Enhancing...":"Enhance prompt"),n&&(n.disabled=e||!A),i&&(i.textContent=e?"Enhancing...":"",i.style.display=e?"inline-flex":"none"),o&&(o.disabled=e),_(A)}async function X(){if(!w)return;const e=F(w).trim();if(!e)return d("Nothing to save","error");const t=await z({text:e,source:"claude",url:location.href});if(t.ok)return d(`Saved (${t.count}/${t.max})`,"success");if(t.reason==="limit")return d("Limit reached","error");if(t.reason==="empty")return d("Nothing to save","error")}function ue(e,t){const n=document.getElementById("pp-enhance-preview");n&&n.remove();const i=document.createElement("div");i.id="pp-enhance-preview",i.style.cssText=`
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.45);
    z-index: 1000000;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
  `;const o=x==="dark"?"rgba(25, 25, 28, 0.98)":"#ffffff",r=x==="dark"?"#f9fafb":"#111827",c=x==="dark"?"rgba(255, 255, 255, 0.12)":"rgba(0, 0, 0, 0.12)",l=x==="dark"?"rgba(15, 15, 18, 0.95)":"rgba(248, 248, 248, 0.98)",p=document.createElement("div");p.style.cssText=`
    background: ${o};
    color: ${r};
    border: 1px solid ${c};
    border-radius: 12px;
    width: min(900px, 100%);
    max-height: 80vh;
    display: flex;
    flex-direction: column;
    gap: 12px;
    padding: 16px;
    box-shadow: 0 24px 60px rgba(0,0,0,0.35);
  `;const h=document.createElement("div");h.textContent="Enhance preview",h.style.cssText=`
    font-size: 14px;
    font-weight: 600;
    font-family: ${E.light.font};
  `;const b=document.createElement("div");b.style.cssText=`
    display: flex;
    gap: 12px;
    flex: 1;
    overflow: auto;
  `,window.innerWidth<720&&(b.style.flexDirection="column");const f=(s,T)=>{const S=document.createElement("div");S.style.cssText=`
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 6px;
      min-width: 0;
    `;const M=document.createElement("div");M.textContent=s,M.style.cssText="font-size: 12px; opacity: 0.75;";const I=document.createElement("textarea");return I.readOnly=!0,I.value=T,I.style.cssText=`
      flex: 1;
      min-height: 180px;
      resize: vertical;
      background: ${l};
      color: ${r};
      border: 1px solid ${c};
      border-radius: 8px;
      padding: 10px;
      font-size: 12px;
      line-height: 1.4;
      font-family: ${E.light.font};
    `,S.appendChild(M),S.appendChild(I),S};b.appendChild(f("Before",e)),b.appendChild(f("After",t));const a=document.createElement("div");a.style.cssText=`
    display: flex;
    gap: 8px;
    justify-content: flex-end;
  `;const v=s=>{const T=document.createElement("button");return T.type="button",T.textContent=s,T.style.cssText=`
      padding: 8px 12px;
      border-radius: 8px;
      border: 1px solid ${c};
      background: ${l};
      color: ${r};
      font-size: 12px;
      cursor: pointer;
      font-family: ${E.light.font};
    `,T},m=v("Replace"),u=v("Save"),g=v("Cancel"),C=()=>{i.remove(),document.removeEventListener("keydown",j)},N=async()=>{try{await navigator.clipboard.writeText(t),d("Copied to clipboard","success")}catch{d("Failed to copy","error")}},j=s=>{if(s.key==="Escape"){s.preventDefault(),C();return}if((s.ctrlKey||s.metaKey)&&s.key.toLowerCase()==="c"){s.preventDefault(),s.stopPropagation(),N();return}if(s.altKey&&s.shiftKey&&s.key.toLowerCase()==="s"){s.preventDefault(),s.stopPropagation(),u.click();return}if(s.key==="Enter"&&!s.shiftKey&&!s.ctrlKey&&!s.altKey&&!s.metaKey){s.preventDefault(),s.stopPropagation(),m.click();return}},V=x==="dark"?E.dark:E.light;m.style.background=V.accent,m.style.color="#ffffff",m.style.border="none",m.addEventListener("click",()=>{const s=k();s&&(w=s,se(s,t),s.focus(),C(),d("Prompt replaced","success"))});const Q=chrome.runtime.getURL("img/icon-16.png");u.title="Save to PromptPack",u.setAttribute("aria-label","Save to PromptPack"),u.innerHTML=`<img src="${Q}" width="16" height="16" alt="">`,u.style.padding="6px",u.style.width="32px",u.style.height="32px",u.style.display="inline-flex",u.style.alignItems="center",u.style.justifyContent="center",u.addEventListener("click",async()=>{const s=await z({text:t,source:"claude",url:location.href});if(s.ok){d(`Saved (${s.count}/${s.max})`,"success");return}if(s.reason==="limit")return d("Limit reached","error");if(s.reason==="empty")return d("Nothing to save","error");d("Failed to save","error")}),g.addEventListener("click",C),i.addEventListener("click",s=>{s.target===i&&C()}),document.addEventListener("keydown",j),a.appendChild(m),a.appendChild(u),a.appendChild(g),p.appendChild(h),p.appendChild(b),p.appendChild(a),i.appendChild(p),document.body.appendChild(i)}async function J(){if(q||!w)return;const e=F(w).trim();if(!e)return;if(e.length>6e3){d("Prompt too long to enhance. Try shortening it.","error");return}const t=await pe();if(!t){d("Sign in to use enhance feature","error");return}D(!0);try{const n={"Content-Type":"application/json",Authorization:`Bearer ${t}`},i=await fetch(ne,{method:"POST",headers:n,body:JSON.stringify({text:e,mode:P})});if(i.status===429){const r=await i.json().catch(()=>({error:""})),c=typeof r.error=="string"&&r.error.trim()?r.error:"You've hit the enhance limit. Try again later.";d(c,"error");return}if(i.status===400&&(await i.json().catch(()=>({error:""}))).error?.toLowerCase().includes("too long")){d("Prompt too long to enhance. Try shortening it.","error");return}if(!i.ok){d("Enhance failed. Try again.","error");return}const o=await i.json();if(!o.enhanced){d("Enhance failed. Try again.","error");return}ue(e,o.enhanced)}catch{d("Enhance failed. Check your connection.","error")}finally{D(!1)}}function G(){let e=de();if(!e){const t=document.getElementById("pp-enhance-wrap");t&&t.remove(),ce(),e=document.createElement("div"),e.id="pp-enhance-wrap",e.style.cssText=`
      position: fixed;
      z-index: 999999;
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px;
      border-radius: 999px;
      user-select: none;
    `;const n=document.createElement("select");n.id="pp-enhance-mode",n.title="Enhance mode",n.style.cssText=`
      height: 32px;
      padding: 4px 12px;
      border-radius: 999px;
      font-size: 13px;
      cursor: pointer;
      outline: none;
      max-width: 130px;
    `,[{value:"structured",label:"Structured"},{value:"clarity",label:"Clarity"},{value:"concise",label:"Concise"},{value:"strict",label:"Strict"}].forEach(l=>{const p=document.createElement("option");p.value=l.value,p.textContent=l.label,n.appendChild(p)}),n.value=P,n.addEventListener("change",()=>{P=n.value});const o=document.createElement("button");o.id="pp-enhance-btn",o.type="button",o.title="Enhance prompt",o.setAttribute("aria-label","Enhance prompt"),o.style.cssText=`
      width: 36px;
      height: 36px;
      border-radius: 999px;
      padding: 0;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
    `,o.innerHTML=W,o.addEventListener("click",l=>{l.stopPropagation(),J()});const r=document.createElement("button");r.id="pp-save-btn",r.type="button",r.title="Save prompt",r.setAttribute("aria-label","Save prompt"),r.textContent="Save",r.style.cssText=`
      height: 32px;
      padding: 0 14px;
      border-radius: 999px;
      font-size: 13px;
      line-height: 1;
      cursor: pointer;
      font-family: ${E.light.font};
    `,r.addEventListener("click",l=>{l.stopPropagation(),X()});const c=document.createElement("span");c.id="pp-enhance-status",c.style.cssText=`
      display: none;
      font-size: 11px;
      opacity: 0.8;
      margin-left: 4px;
      color: ${E.light.text};
      font-family: ${E.light.font};
    `,e.appendChild(n),e.appendChild(o),e.appendChild(r),e.appendChild(c),document.body.appendChild(e)}return Y(x),_(A),e}function fe(){document.addEventListener("keydown",e=>{if(!e.altKey||!e.shiftKey||e.key.toLowerCase()!=="s"||e.repeat)return;const t=k();t&&(w=t);const n=e.target;n&&(n.tagName==="INPUT"||n.tagName==="TEXTAREA"||n.isContentEditable)&&(!t||n!==t&&!t.contains(n))||(e.preventDefault(),e.stopPropagation(),X())})}function me(){document.addEventListener("keydown",e=>{if(!e.altKey||!e.shiftKey||e.key.toLowerCase()!=="e"||e.repeat)return;const t=k();t&&(w=t);const n=e.target;n&&(n.tagName==="INPUT"||n.tagName==="TEXTAREA"||n.isContentEditable)&&(!t||n!==t&&!t.contains(n))||(e.preventDefault(),e.stopPropagation(),J())})}function ye(){const e=["structured","clarity","concise","strict"];document.addEventListener("keydown",t=>{if(!t.altKey||t.shiftKey||t.ctrlKey||t.metaKey||t.repeat)return;const n=parseInt(t.key,10);if(n<1||n>4)return;const i=k();if(!i)return;const o=t.target;if(o&&(o.tagName==="INPUT"||o.tagName==="TEXTAREA"||o.isContentEditable)&&o!==i&&!i.contains(o))return;t.preventDefault(),t.stopPropagation();const r=e[n-1];P=r;const c=document.getElementById("pp-enhance-mode");c&&(c.value=r),d(`Mode: ${r.charAt(0).toUpperCase()+r.slice(1)}`,"success")})}function he(){const e=['button[aria-label*="Stop"]','button[aria-label*="stop"]','button[title*="Stop"]','button[title*="stop"]'];for(const t of e){const n=document.querySelector(t);if(n&&$(n))return!0}return!1}function ge(e){const t=document.createElement("button");t.className="pp-bubble-save-icon",t.type="button",t.setAttribute("aria-label","Save prompt to PromptPack"),t.title="Save to PromptPack",t.__promptText=e,t.style.cssText=`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    padding: 4px;
    margin: 0;
    border-radius: 6px;
    cursor: pointer;
    transition: background-color 0.15s ease, opacity 0.15s ease;
    border: none;
    background: transparent;
    opacity: 0;
    flex-shrink: 0;
  `,t.addEventListener("mouseenter",()=>{t.style.background=x==="dark"?"rgba(255, 255, 255, 0.1)":"rgba(0, 0, 0, 0.05)",t.style.opacity="1"}),t.addEventListener("mouseleave",()=>{t.style.background="transparent",t.style.opacity="0.5"});const n=chrome.runtime.getURL("img/icon-16.png");return t.innerHTML=`<img src="${n}" width="16" height="16" alt="Save">`,t.addEventListener("click",async i=>{i.stopPropagation(),i.preventDefault();const o=i.currentTarget.__promptText;if(!o){d("No prompt to save","error");return}const r=await z({text:o,source:"claude",url:location.href});r.ok?(t.style.opacity="1",d(`Saved! (${r.count}/${r.max})`,"success")):r.reason==="limit"?d("Limit reached","error"):r.reason==="empty"&&d("Nothing to save","error")}),t}function xe(){document.querySelectorAll('div[data-testid="user-message"]').forEach(t=>{if(H.has(t))return;const i=t.querySelector("p.whitespace-pre-wrap")?.textContent?.trim()||"";if(!i||i.length<2)return;let o=t.parentElement,r=null,c=0;for(;o&&c<5;){const f=o.querySelectorAll("button");for(const a of f)if(a.querySelector('svg path[d*="M12.5 3C13.3284"]')){const m=a.closest("[data-testid]");if((!m||m.getAttribute("data-testid")!=="user-message")&&o.querySelector('div[data-testid="user-message"]')===t){r=a;break}}if(r)break;o=o.parentElement,c++}if(!r)return;const l=r.parentElement;if(!l||l.querySelector(".pp-bubble-save-icon"))return;H.add(t);const p=ge(i);r.nextSibling?l.insertBefore(p,r.nextSibling):l.appendChild(p);const h=()=>{p.style.opacity="1"},b=()=>{p.style.opacity="0"};l.addEventListener("mouseenter",h),l.addEventListener("mouseleave",b),t.addEventListener("mouseenter",h),t.addEventListener("mouseleave",b),p.__cleanup=()=>{l.removeEventListener("mouseenter",h),l.removeEventListener("mouseleave",b),t.removeEventListener("mouseenter",h),t.removeEventListener("mouseleave",b)}})}function L(){R||(R=!0,requestAnimationFrame(()=>{R=!1,K()}))}function K(){if(location.href!==O){O=location.href;const o=document.getElementById("pp-enhance-wrap");o&&o.remove(),H.clear()}xe();const e=k();if(w=e,!e){const o=G();o.style.display="none";return}const t=F(e).trim(),n=G();if(_(t.length>0),he()){n.style.display="none";return}n.style.display="flex",ae(n)}function be(){ee({onChange:o=>{x=o,Y(x)},persistToStorage:!0}),K();let e=0;const t=setInterval(()=>{K(),e++,e>=10&&clearInterval(t)},200);U=new MutationObserver(L),U.observe(document.documentElement,{childList:!0,subtree:!0}),window.addEventListener("resize",L),window.addEventListener("scroll",L,{passive:!0}),fe(),me(),ye();const n=history.pushState.bind(history),i=history.replaceState.bind(history);history.pushState=function(...o){n(...o),L()},history.replaceState=function(...o){i(...o),L()},window.addEventListener("popstate",L),ke()}let y=null;function ve(){const e=document.createElement("div");return e.id="pp-context-menu",e.style.cssText=`
    position: fixed;
    z-index: 999999;
    background: ${x==="dark"?"#2d2d2d":"#ffffff"};
    border: 1px solid ${x==="dark"?"#444":"#ddd"};
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    min-width: 200px;
    max-width: 300px;
    max-height: 400px;
    overflow: hidden;
    overflow-y: auto;
    padding: 0;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
    font-size: 13px;
    display: none;
  `,document.body.appendChild(e),e}function B(){y&&(y.style.display="none")}async function Ee(e,t){y||(y=ve());const n=await te("claude"),i=n.reduce((p,h)=>p+h.prompts.length,0),o=x==="dark"?{bg:"#2d2d2d",border:"#444",text:"#e5e5e5",hover:"#3d3d3d",secondary:"#999"}:{bg:"#ffffff",border:"#ddd",text:"#333",hover:"#f5f5f5",secondary:"#666"};if(y.style.background=o.bg,y.style.borderColor=o.border,y.style.color=o.text,i===0)y.innerHTML=`
      <div style="padding: 12px 16px; color: ${o.secondary}; text-align: center;">
        No saved Claude prompts yet
      </div>
    `;else{const p=n.map((f,a)=>({group:f,index:a})).filter(({group:f})=>f.prompts.length>0);y.innerHTML=`
      <div style="padding: 8px 12px; font-weight: 600; border-bottom: 1px solid ${o.border}; display: flex; align-items: center; gap: 8px;">
        <img src="${chrome.runtime.getURL("img/icon-16.png")}" width="16" height="16">
        PromptPack
      </div>
      ${p.map(({group:f,index:a},v)=>{const u=v===p.length-1?"none":`1px solid ${o.border}`;return`
          <div class="pp-group" data-group-index="${a}">
            <div class="pp-group-header" data-group-index="${a}" style="
              padding: 8px 12px;
              cursor: pointer;
              border-bottom: ${u};
              font-weight: 500;
              display: flex;
              align-items: center;
              gap: 6px;
            ">
              <span class="pp-arrow" style="transition: transform 0.2s;">▶</span>
              ${f.displayName} (${f.prompts.length})
            </div>
            <div class="pp-group-items" data-group-index="${a}" style="display: none;">
              ${f.prompts.map((g,C)=>{const N=g.header?g.header:g.text.length>50?g.text.substring(0,50)+"...":g.text;return`
                <div class="pp-menu-item" data-group-index="${a}" data-prompt-index="${C}" style="
                  padding: 8px 12px 8px 28px;
                  cursor: pointer;
                  border-bottom: ${C<f.prompts.length-1?`1px solid ${o.border}`:"none"};
                  overflow: hidden;
                  text-overflow: ellipsis;
                  white-space: nowrap;
                " title="${g.text.replace(/"/g,"&quot;")}">
                  ${N}
                </div>
              `}).join("")}
            </div>
          </div>
        `}).join("")}
    `,y.querySelectorAll(".pp-group-header").forEach(f=>{const a=f;a.addEventListener("mouseenter",()=>{a.style.background=o.hover}),a.addEventListener("mouseleave",()=>{a.style.background="transparent"}),a.addEventListener("click",()=>{const v=a.dataset.groupIndex,m=y.querySelector(`.pp-group-items[data-group-index="${v}"]`),u=a.querySelector(".pp-arrow");if(m){const g=m.style.display!=="none";m.style.display=g?"none":"block",u&&(u.style.transform=g?"rotate(0deg)":"rotate(90deg)")}})}),y.querySelectorAll(".pp-menu-item").forEach(f=>{const a=f,v=parseInt(a.dataset.groupIndex||"0",10),m=parseInt(a.dataset.promptIndex||"0",10);a.addEventListener("mouseenter",()=>{a.style.background=o.hover}),a.addEventListener("mouseleave",()=>{a.style.background="transparent"}),a.addEventListener("click",()=>{const u=n[v];u&&u.prompts[m]&&(we(u.prompts[m].text),B())})})}const r={width:250,height:300};let c=e,l=t;c+r.width>window.innerWidth&&(c=window.innerWidth-r.width-10),l+r.height>window.innerHeight&&(l=window.innerHeight-r.height-10),y.style.left=`${c}px`,y.style.top=`${l}px`,y.style.display="block"}function we(e){const t=k();t&&(t instanceof HTMLTextAreaElement?(t.value=e,t.dispatchEvent(new Event("input",{bubbles:!0}))):t.isContentEditable&&(t.innerText=e,t.dispatchEvent(new Event("input",{bubbles:!0}))),t.focus())}function ke(){document.addEventListener("contextmenu",e=>{const t=e.target,n=k();n&&(t===n||n.contains(t))&&(e.preventDefault(),Ee(e.clientX,e.clientY))}),document.addEventListener("click",e=>{y&&!y.contains(e.target)&&B()}),document.addEventListener("keydown",e=>{e.key==="Escape"&&B()}),document.addEventListener("scroll",B,{passive:!0})}be();
