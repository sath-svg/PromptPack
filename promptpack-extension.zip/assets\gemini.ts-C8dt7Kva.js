import{m as Z,s as ee,t as E,n as _,o as te}from"./theme-COKq0XYb.js";import{E as ne}from"./db-3tdwsUDZ.js";import"./api-BDkNmw7T.js";const oe=150,re=90,Y=`
  <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path d="M9 3l1.5 4.5L15 9l-4.5 1.5L9 15l-1.5-4.5L3 9l4.5-1.5L9 3z"></path>
    <path d="M18 3l1 2.5L21.5 6l-2.5 1L18 9.5l-1-2.5L14.5 6l2.5-1L18 3z"></path>
  </svg>
`,ie=`
  <svg class="pp-spin" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true">
    <circle cx="12" cy="12" r="9" stroke-dasharray="42" stroke-dashoffset="12"></circle>
  </svg>
`;function c(e,t="success"){let n=document.getElementById("pp-toast");n||(n=document.createElement("div"),n.id="pp-toast",n.style.cssText=`
      position: absolute;
      z-index: 1000001;
      padding: 10px 12px;
      border-radius: 8px;
      color: white;
      font-size: 13px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.25);
      opacity: 0;
      transform: translateY(6px);
      transition: opacity 140ms ease, transform 140ms ease;
      font-family: Google Sans, Roboto, ui-sans-serif, system-ui, -apple-system, Arial;
      pointer-events: none;
    `,document.body.appendChild(n)),n.style.background=t==="error"?"rgba(220, 38, 38, 0.92)":"rgba(59, 130, 246, 0.92)";const i=k();if(i){const o=i.getBoundingClientRect(),r=200,a=80;n.style.position="fixed",n.style.left=`${o.right+a}px`,n.style.top=`${o.top}px`,o.right+a+r>window.innerWidth&&(n.style.left=`${o.left-r-a}px`)}else n.style.position="fixed",n.style.right="16px",n.style.bottom="140px";n.textContent=e,n.style.opacity="1",n.style.transform="translateY(0)",window.setTimeout(()=>{n.style.opacity="0",n.style.transform="translateY(6px)"},1400)}function B(e){const t=e.getBoundingClientRect(),n=window.getComputedStyle(e);return t.width>10&&t.height>10&&n.display!=="none"&&n.visibility!=="hidden"&&n.opacity!=="0"}function k(){const e=document.querySelector('div[contenteditable="true"][role="textbox"], div[contenteditable="true"][aria-label*="prompt"], div[contenteditable="true"][aria-label*="message"]');if(e&&B(e))return e;const t=o=>{let r=o.parentElement,a=0;for(;r&&a<20;){const d=r.getAttribute("role"),m=r.getAttribute("aria-modal");if(d==="dialog"||m==="true"||r.classList.contains("modal")||r.classList.contains("settings"))return!1;if(r.tagName==="FORM"){const h=r.className.toLowerCase();if(h.includes("setting")||h.includes("preference"))return!1}r=r.parentElement,a++}if(o instanceof HTMLTextAreaElement){const d=o.placeholder.toLowerCase();if(d.includes("additional behavior")||d.includes("preference")||d.includes("custom instruction"))return!1}return!0},n=Array.from(document.querySelectorAll('[contenteditable="true"]')).filter(B).filter(t);if(n.length)return n.sort((o,r)=>r.clientWidth*r.clientHeight-o.clientWidth*o.clientHeight),n[0];const i=Array.from(document.querySelectorAll("textarea")).filter(B).filter(t);return i.length?(i.sort((o,r)=>r.clientWidth*r.clientHeight-o.clientWidth*o.clientHeight),i[0]):null}function F(e){return e instanceof HTMLTextAreaElement?e.value??"":e.innerText??""}function se(e,t){if(e instanceof HTMLTextAreaElement){const n=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value")?.set;n?n.call(e,t):e.value=t,e.dispatchEvent(new InputEvent("input",{bubbles:!0,inputType:"insertText",data:t}));return}e.textContent=t,e.dispatchEvent(new InputEvent("input",{bubbles:!0,inputType:"insertText",data:t}))}function ae(e){e.style.right=`${oe}px`,e.style.bottom=`${re}px`,e.style.left="auto",e.style.top="auto"}function le(){if(document.getElementById("pp-enhance-styles"))return;const e=document.createElement("style");e.id="pp-enhance-styles",e.textContent=`
    @keyframes pp-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
    .pp-spin { animation: pp-spin 0.9s linear infinite; }

    /* Gemini dropdown styling - light theme */
    #pp-enhance-mode option {
      background: rgb(245, 245, 245);
      color: rgba(0, 0, 0, 0.87);
    }
    #pp-enhance-mode:focus {
      outline: 2px solid rgba(0, 0, 0, 0.12);
      outline-offset: 2px;
    }

    /* Gemini dropdown styling - dark theme */
    @media (prefers-color-scheme: dark) {
      #pp-enhance-mode option {
        background: rgb(32, 33, 36);
        color: rgba(255, 255, 255, 0.87);
      }
      #pp-enhance-mode:focus {
        outline: 2px solid rgba(255, 255, 255, 0.12);
        outline-offset: 2px;
      }
    }
  `,document.head.appendChild(e)}function ce(e,t){const n=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="none" stroke="${t}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5.5 7.5l4.5 4.5 4.5-4.5"/></svg>`;e.style.setProperty("appearance","none"),e.style.setProperty("-webkit-appearance","none"),e.style.backgroundImage=`url("data:image/svg+xml;utf8,${encodeURIComponent(n)}")`,e.style.backgroundRepeat="no-repeat",e.style.backgroundPosition="right 6px center",e.style.backgroundSize="10px 10px",e.style.paddingRight="22px"}function X(e){const t=e==="dark"?E.dark:E.light,n=document.getElementById("pp-enhance-wrap");n&&(n.style.background=t.buttonBg,n.style.border=`1px solid ${t.border}`,n.style.boxShadow=t.shadow,n.style.borderRadius="8px",n.style.fontFamily=t.font,n.style.backdropFilter="none",n.style.webkitBackdropFilter="none");const i=document.getElementById("pp-save-btn");i&&(i.style.background="transparent",i.style.border="none",i.style.color=t.text,i.style.fontFamily=t.font,i.style.borderRadius="8px");const o=document.getElementById("pp-enhance-btn");o&&(o.style.background="transparent",o.style.border="none",o.style.color=t.text,o.style.fontFamily=t.font,o.style.borderRadius="8px");const r=document.getElementById("pp-enhance-mode");r&&(r.style.background=t.buttonBg,r.style.border="none",r.style.color=t.text,r.style.fontFamily=t.font,ce(r,t.text));const a=document.getElementById("pp-enhance-status");a&&(a.style.color=t.text)}let w=null,x=Z(),U=location.href,H=!1,D=null,K=new Set,P="structured",j=!1,A=!1;function de(){const e=document.getElementById("pp-enhance-wrap");return e&&document.body.contains(e)?e:null}async function pe(){return chrome?.runtime?.sendMessage?new Promise(e=>{chrome.runtime.sendMessage({type:"PP_GET_ENHANCE_TOKEN"},t=>{if(chrome.runtime.lastError){e(null);return}const n=t?.token;e(typeof n=="string"?n:null)})}):null}function q(e){A=e;const t=document.getElementById("pp-save-btn"),n=document.getElementById("pp-enhance-btn"),i=!e||j;t&&(t.disabled=i,t.style.opacity=i?"0.6":"1",t.style.cursor=i?"not-allowed":"pointer"),n&&(n.disabled=i,n.style.opacity=i?"0.6":"1",n.style.cursor=i?"not-allowed":"pointer")}function G(e){j=e;const t=document.getElementById("pp-enhance-btn"),n=document.getElementById("pp-save-btn"),i=document.getElementById("pp-enhance-status"),o=document.getElementById("pp-enhance-mode");t&&(t.innerHTML=e?ie:Y,t.setAttribute("aria-busy",e?"true":"false"),t.title=e?"Enhancing...":"Enhance prompt"),n&&(n.disabled=e||!A),i&&(i.textContent=e?"Enhancing...":"",i.style.display=e?"inline-flex":"none"),o&&(o.disabled=e),q(A)}async function J(){if(!w)return;const e=F(w).trim();if(!e)return c("Nothing to save","error");const t=await _({text:e,source:"gemini",url:location.href});if(t.ok)return c(`Saved (${t.count}/${t.max})`,"success");if(t.reason==="limit")return c("Limit reached","error");if(t.reason==="empty")return c("Nothing to save","error")}function ue(e,t){const n=document.getElementById("pp-enhance-preview");n&&n.remove();const i=document.createElement("div");i.id="pp-enhance-preview",i.style.cssText=`
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.45);
    z-index: 1000000;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
  `;const o=x==="dark"?"rgba(15, 15, 15, 0.98)":"#ffffff",r=x==="dark"?"#f9fafb":"#111827",a=x==="dark"?"rgba(255, 255, 255, 0.12)":"rgba(0, 0, 0, 0.12)",d=x==="dark"?"rgba(20, 20, 20, 0.95)":"rgba(245, 245, 245, 0.98)",m=document.createElement("div");m.style.cssText=`
    background: ${o};
    color: ${r};
    border: 1px solid ${a};
    border-radius: 12px;
    width: min(900px, 100%);
    max-height: 80vh;
    display: flex;
    flex-direction: column;
    gap: 12px;
    padding: 16px;
    box-shadow: 0 24px 60px rgba(0,0,0,0.35);
  `;const h=document.createElement("div");h.textContent="Enhance preview",h.style.cssText=`
    font-size: 14px;
    font-weight: 600;
    font-family: ${E.light.font};
  `;const b=document.createElement("div");b.style.cssText=`
    display: flex;
    gap: 12px;
    flex: 1;
    overflow: auto;
  `,window.innerWidth<720&&(b.style.flexDirection="column");const u=(s,T)=>{const S=document.createElement("div");S.style.cssText=`
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 6px;
      min-width: 0;
    `;const R=document.createElement("div");R.textContent=s,R.style.cssText="font-size: 12px; opacity: 0.75;";const $=document.createElement("textarea");return $.readOnly=!0,$.value=T,$.style.cssText=`
      flex: 1;
      min-height: 180px;
      resize: vertical;
      background: ${d};
      color: ${r};
      border: 1px solid ${a};
      border-radius: 8px;
      padding: 10px;
      font-size: 12px;
      line-height: 1.4;
      font-family: ${E.light.font};
    `,S.appendChild(R),S.appendChild($),S};b.appendChild(u("Before",e)),b.appendChild(u("After",t));const l=document.createElement("div");l.style.cssText=`
    display: flex;
    gap: 8px;
    justify-content: flex-end;
  `;const v=s=>{const T=document.createElement("button");return T.type="button",T.textContent=s,T.style.cssText=`
      padding: 8px 12px;
      border-radius: 8px;
      border: 1px solid ${a};
      background: ${d};
      color: ${r};
      font-size: 12px;
      cursor: pointer;
      font-family: ${E.light.font};
    `,T},f=v("Replace"),p=v("Save"),g=v("Cancel"),C=()=>{i.remove(),document.removeEventListener("keydown",O)},N=async()=>{try{await navigator.clipboard.writeText(t),c("Copied to clipboard","success")}catch{c("Failed to copy","error")}},O=s=>{if(s.key==="Escape"){s.preventDefault(),C();return}if((s.ctrlKey||s.metaKey)&&s.key.toLowerCase()==="c"){s.preventDefault(),s.stopPropagation(),N();return}if(s.altKey&&s.shiftKey&&s.key.toLowerCase()==="s"){s.preventDefault(),s.stopPropagation(),p.click();return}if(s.key==="Enter"&&!s.shiftKey&&!s.ctrlKey&&!s.altKey&&!s.metaKey){s.preventDefault(),s.stopPropagation(),f.click();return}},M=x==="dark"?E.dark:E.light;f.style.background=M.buttonBg,f.style.color=M.text,f.style.border=`1px solid ${M.border}`,f.addEventListener("click",()=>{const s=k();s&&(w=s,se(s,t),s.focus(),C(),c("Prompt replaced","success"))});const Q=chrome.runtime.getURL("img/icon-16.png");p.title="Save to PromptPack",p.setAttribute("aria-label","Save to PromptPack"),p.innerHTML=`<img src="${Q}" width="16" height="16" alt="">`,p.style.padding="6px",p.style.width="32px",p.style.height="32px",p.style.display="inline-flex",p.style.alignItems="center",p.style.justifyContent="center",p.addEventListener("click",async()=>{const s=await _({text:t,source:"gemini",url:location.href});if(s.ok){c(`Saved (${s.count}/${s.max})`,"success");return}if(s.reason==="limit")return c("Limit reached","error");if(s.reason==="empty")return c("Nothing to save","error");c("Failed to save","error")}),g.addEventListener("click",C),i.addEventListener("click",s=>{s.target===i&&C()}),document.addEventListener("keydown",O),l.appendChild(f),l.appendChild(p),l.appendChild(g),m.appendChild(h),m.appendChild(b),m.appendChild(l),i.appendChild(m),document.body.appendChild(i)}async function V(){if(j||!w)return;const e=F(w).trim();if(!e)return;if(e.length>6e3){c("Prompt too long to enhance. Try shortening it.","error");return}const t=await pe();if(!t){c("Sign in to use enhance feature","error");return}G(!0);try{const n={"Content-Type":"application/json",Authorization:`Bearer ${t}`},i=await fetch(ne,{method:"POST",headers:n,body:JSON.stringify({text:e,mode:P})});if(i.status===429){const r=await i.json().catch(()=>({error:""})),a=typeof r.error=="string"&&r.error.trim()?r.error:"You've hit the enhance limit. Try again later.";c(a,"error");return}if(i.status===400&&(await i.json().catch(()=>({error:""}))).error?.toLowerCase().includes("too long")){c("Prompt too long to enhance. Try shortening it.","error");return}if(!i.ok){c("Enhance failed. Try again.","error");return}const o=await i.json();if(!o.enhanced){c("Enhance failed. Try again.","error");return}ue(e,o.enhanced)}catch{c("Enhance failed. Check your connection.","error")}finally{G(!1)}}function W(){let e=de();if(!e){const t=document.getElementById("pp-enhance-wrap");t&&t.remove(),le(),e=document.createElement("div"),e.id="pp-enhance-wrap",e.style.cssText=`
      position: fixed;
      z-index: 999999;
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px;
      border-radius: 999px;
      user-select: none;
    `;const n=document.createElement("select");n.id="pp-enhance-mode",n.title="Enhance mode",n.style.cssText=`
      height: 32px;
      padding: 4px 12px;
      border-radius: 999px;
      font-size: 13px;
      cursor: pointer;
      outline: none;
      max-width: 130px;
    `,[{value:"structured",label:"Structured"},{value:"clarity",label:"Clarity"},{value:"concise",label:"Concise"},{value:"strict",label:"Strict"}].forEach(d=>{const m=document.createElement("option");m.value=d.value,m.textContent=d.label,n.appendChild(m)}),n.value=P,n.addEventListener("change",()=>{P=n.value});const o=document.createElement("button");o.id="pp-enhance-btn",o.type="button",o.title="Enhance prompt",o.setAttribute("aria-label","Enhance prompt"),o.style.cssText=`
      width: 36px;
      height: 36px;
      border-radius: 999px;
      padding: 0;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
    `,o.innerHTML=Y,o.addEventListener("click",d=>{d.stopPropagation(),V()});const r=document.createElement("button");r.id="pp-save-btn",r.type="button",r.title="Save prompt",r.setAttribute("aria-label","Save prompt"),r.textContent="Save",r.style.cssText=`
      height: 32px;
      padding: 0 14px;
      border-radius: 999px;
      font-size: 13px;
      line-height: 1;
      cursor: pointer;
      font-family: ${E.light.font};
    `,r.addEventListener("click",d=>{d.stopPropagation(),J()});const a=document.createElement("span");a.id="pp-enhance-status",a.style.cssText=`
      display: none;
      font-size: 11px;
      opacity: 0.8;
      margin-left: 4px;
      color: ${E.light.text};
      font-family: ${E.light.font};
    `,e.appendChild(n),e.appendChild(o),e.appendChild(r),e.appendChild(a),document.body.appendChild(e)}return X(x),q(A),e}function me(){document.addEventListener("keydown",e=>{if(!e.altKey||!e.shiftKey||e.key.toLowerCase()!=="s"||e.repeat)return;const t=k();t&&(w=t);const n=e.target;n&&(n.tagName==="INPUT"||n.tagName==="TEXTAREA"||n.isContentEditable)&&(!t||n!==t&&!t.contains(n))||(e.preventDefault(),e.stopPropagation(),J())})}function fe(){document.addEventListener("keydown",e=>{if(!e.altKey||!e.shiftKey||e.key.toLowerCase()!=="e"||e.repeat)return;const t=k();t&&(w=t);const n=e.target;n&&(n.tagName==="INPUT"||n.tagName==="TEXTAREA"||n.isContentEditable)&&(!t||n!==t&&!t.contains(n))||(e.preventDefault(),e.stopPropagation(),V())})}function ye(){const e=["structured","clarity","concise","strict"];document.addEventListener("keydown",t=>{if(!t.altKey||t.shiftKey||t.ctrlKey||t.metaKey||t.repeat)return;const n=parseInt(t.key,10);if(n<1||n>4)return;const i=k();if(!i)return;const o=t.target;if(o&&(o.tagName==="INPUT"||o.tagName==="TEXTAREA"||o.isContentEditable)&&o!==i&&!i.contains(o))return;t.preventDefault(),t.stopPropagation();const r=e[n-1];P=r;const a=document.getElementById("pp-enhance-mode");a&&(a.value=r),c(`Mode: ${r.charAt(0).toUpperCase()+r.slice(1)}`,"success")})}function he(){const e=['button[aria-label*="Stop"]','button[aria-label*="stop"]','button[title*="Stop"]','button[title*="stop"]'];for(const t of e){const n=document.querySelector(t);if(n&&B(n))return!0}return!1}function ge(e){const t=document.createElement("button");t.className="pp-bubble-save-icon",t.type="button",t.setAttribute("aria-label","Save prompt to PromptPack"),t.title="Save to PromptPack",t.__promptText=e,t.style.cssText=`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    padding: 4px;
    margin: 0;
    border-radius: 6px;
    cursor: pointer;
    transition: background-color 0.15s ease, opacity 0.15s ease;
    border: none;
    background: transparent;
    opacity: 0;
    flex-shrink: 0;
  `,t.addEventListener("mouseenter",()=>{t.style.background=x==="dark"?"rgba(255, 255, 255, 0.1)":"rgba(0, 0, 0, 0.05)",t.style.opacity="1"}),t.addEventListener("mouseleave",()=>{t.style.background="transparent",t.style.opacity="0.5"});const n=chrome.runtime.getURL("img/icon-16.png");return t.innerHTML=`<img src="${n}" width="16" height="16" alt="Save">`,t.addEventListener("click",async i=>{i.stopPropagation(),i.preventDefault();const o=i.currentTarget.__promptText;if(!o){c("No prompt to save","error");return}const r=await _({text:o,source:"gemini",url:location.href});r.ok?(t.style.opacity="1",c(`Saved! (${r.count}/${r.max})`,"success")):r.reason==="limit"?c("Limit reached","error"):r.reason==="empty"&&c("Nothing to save","error")}),t}function xe(){document.querySelectorAll('mat-icon[fonticon="content_copy"], mat-icon[data-mat-icon-name="content_copy"]').forEach(t=>{const n=t.closest("button");if(!n)return;const i=n.parentElement;if(!i||i.querySelector(".pp-bubble-save-icon"))return;let o=n.parentElement,r="",a=null,d=!1,m=0;for(;o&&m<15;){const l=o.querySelectorAll("p.query-text-line");if(l.length>0){r=Array.from(l).map(f=>f.textContent?.trim()||"").filter(f=>f.length>0).join(`
`).trim(),a=o,d=!0;break}if(o.querySelector(".model-response-text, message-content, .response-container"))return;o=o.parentElement,m++}if(!d||!r||r.length<2||K.has(n))return;K.add(n);const h=ge(r);i.insertBefore(h,n);const b=()=>{h.style.opacity="1"},u=()=>{h.style.opacity="0"};i.addEventListener("mouseenter",b),i.addEventListener("mouseleave",u),a&&(a.addEventListener("mouseenter",b),a.addEventListener("mouseleave",u)),h.__cleanup=()=>{i.removeEventListener("mouseenter",b),i.removeEventListener("mouseleave",u),a&&(a.removeEventListener("mouseenter",b),a.removeEventListener("mouseleave",u))}})}function L(){H||(H=!0,requestAnimationFrame(()=>{H=!1,z()}))}function z(){if(location.href!==U){U=location.href;const o=document.getElementById("pp-enhance-wrap");o&&o.remove(),K.clear()}xe();const e=k();if(w=e,!e){const o=W();o.style.display="none";return}const t=F(e).trim(),n=W();if(q(t.length>0),he()){n.style.display="none";return}n.style.display="flex",ae(n)}function be(){ee({onChange:o=>{x=o,X(x)},persistToStorage:!0}),z();let e=0;const t=setInterval(()=>{z(),e++,e>=10&&clearInterval(t)},200);D=new MutationObserver(L),D.observe(document.documentElement,{childList:!0,subtree:!0}),window.addEventListener("resize",L),window.addEventListener("scroll",L,{passive:!0}),me(),fe(),ye();const n=history.pushState.bind(history),i=history.replaceState.bind(history);history.pushState=function(...o){n(...o),L()},history.replaceState=function(...o){i(...o),L()},window.addEventListener("popstate",L),ke()}let y=null;function ve(){const e=document.createElement("div");return e.id="pp-context-menu",e.style.cssText=`
    position: fixed;
    z-index: 999999;
    background: ${x==="dark"?"#2d2d2d":"#ffffff"};
    border: 1px solid ${x==="dark"?"#444":"#ddd"};
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    min-width: 200px;
    max-width: 300px;
    max-height: 400px;
    overflow: hidden;
    overflow-y: auto;
    padding: 0;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
    font-size: 13px;
    display: none;
  `,document.body.appendChild(e),e}function I(){y&&(y.style.display="none")}async function Ee(e,t){y||(y=ve());const n=await te("gemini"),i=n.reduce((m,h)=>m+h.prompts.length,0),o=x==="dark"?{bg:"#2d2d2d",border:"#444",text:"#e5e5e5",hover:"#3d3d3d",secondary:"#999"}:{bg:"#ffffff",border:"#ddd",text:"#333",hover:"#f5f5f5",secondary:"#666"};if(y.style.background=o.bg,y.style.borderColor=o.border,y.style.color=o.text,i===0)y.innerHTML=`
      <div style="padding: 12px 16px; color: ${o.secondary}; text-align: center;">
        No saved Gemini prompts yet
      </div>
    `;else{const m=n.map((u,l)=>({group:u,index:l})).filter(({group:u})=>u.prompts.length>0);y.innerHTML=`
      <div style="padding: 8px 12px; font-weight: 600; border-bottom: 1px solid ${o.border}; display: flex; align-items: center; gap: 8px;">
        <img src="${chrome.runtime.getURL("img/icon-16.png")}" width="16" height="16">
        PromptPack
      </div>
      ${m.map(({group:u,index:l},v)=>{const p=v===m.length-1?"none":`1px solid ${o.border}`;return`
          <div class="pp-group" data-group-index="${l}">
            <div class="pp-group-header" data-group-index="${l}" style="
              padding: 8px 12px;
              cursor: pointer;
              border-bottom: ${p};
              font-weight: 500;
              display: flex;
              align-items: center;
              gap: 6px;
            ">
              <span class="pp-arrow" style="transition: transform 0.2s;">▶</span>
              ${u.displayName} (${u.prompts.length})
            </div>
            <div class="pp-group-items" data-group-index="${l}" style="display: none;">
              ${u.prompts.map((g,C)=>{const N=g.header?g.header:g.text.length>50?g.text.substring(0,50)+"...":g.text;return`
                <div class="pp-menu-item" data-group-index="${l}" data-prompt-index="${C}" style="
                  padding: 8px 12px 8px 28px;
                  cursor: pointer;
                  border-bottom: ${C<u.prompts.length-1?`1px solid ${o.border}`:"none"};
                  overflow: hidden;
                  text-overflow: ellipsis;
                  white-space: nowrap;
                " title="${g.text.replace(/"/g,"&quot;")}">
                  ${N}
                </div>
              `}).join("")}
            </div>
          </div>
        `}).join("")}
    `,y.querySelectorAll(".pp-group-header").forEach(u=>{const l=u;l.addEventListener("mouseenter",()=>{l.style.background=o.hover}),l.addEventListener("mouseleave",()=>{l.style.background="transparent"}),l.addEventListener("click",()=>{const v=l.dataset.groupIndex,f=y.querySelector(`.pp-group-items[data-group-index="${v}"]`),p=l.querySelector(".pp-arrow");if(f){const g=f.style.display!=="none";f.style.display=g?"none":"block",p&&(p.style.transform=g?"rotate(0deg)":"rotate(90deg)")}})}),y.querySelectorAll(".pp-menu-item").forEach(u=>{const l=u,v=parseInt(l.dataset.groupIndex||"0",10),f=parseInt(l.dataset.promptIndex||"0",10);l.addEventListener("mouseenter",()=>{l.style.background=o.hover}),l.addEventListener("mouseleave",()=>{l.style.background="transparent"}),l.addEventListener("click",()=>{const p=n[v];p&&p.prompts[f]&&(we(p.prompts[f].text),I())})})}const r={width:250,height:300};let a=e,d=t;a+r.width>window.innerWidth&&(a=window.innerWidth-r.width-10),d+r.height>window.innerHeight&&(d=window.innerHeight-r.height-10),y.style.left=`${a}px`,y.style.top=`${d}px`,y.style.display="block"}function we(e){const t=k();t&&(t instanceof HTMLTextAreaElement?(t.value=e,t.dispatchEvent(new Event("input",{bubbles:!0}))):t.isContentEditable&&(t.innerText=e,t.dispatchEvent(new Event("input",{bubbles:!0}))),t.focus())}function ke(){document.addEventListener("contextmenu",e=>{const t=e.target,n=k();n&&(t===n||n.contains(t))&&(e.preventDefault(),Ee(e.clientX,e.clientY))}),document.addEventListener("click",e=>{y&&!y.contains(e.target)&&I()}),document.addEventListener("keydown",e=>{e.key==="Escape"&&I()}),document.addEventListener("scroll",I,{passive:!0})}be();
