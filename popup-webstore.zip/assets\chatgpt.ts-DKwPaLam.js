import{d as E,s as T,a as B,c as y}from"./theme-JNxzt-1B.js";function h(t){let e=document.getElementById("pp-toast");e||(e=document.createElement("div"),e.id="pp-toast",e.style.cssText=`
      position: fixed;
      right: 16px;
      bottom: 140px;
      z-index: 999999;
      padding: 10px 12px;
      border-radius: 12px;
      background: rgba(220, 38, 38, 0.92);
      color: white;
      font-size: 13px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.25);
      opacity: 0;
      transform: translateY(6px);
      transition: opacity 140ms ease, transform 140ms ease;
      font-family: "Open Sans", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Arial;
    `,document.body.appendChild(e)),e.textContent=t,e.style.opacity="1",e.style.transform="translateY(0)",window.setTimeout(()=>{e.style.opacity="0",e.style.transform="translateY(6px)"},1400)}function a(t){const e=t.getBoundingClientRect(),n=window.getComputedStyle(t);return e.width>10&&e.height>10&&n.display!=="none"&&n.visibility!=="hidden"&&n.opacity!=="0"}function x(){const t=document.querySelector("textarea#prompt-textarea");if(t&&a(t))return t;const e=Array.from(document.querySelectorAll("textarea")).filter(a);if(e.length)return e.sort((r,o)=>o.clientWidth*o.clientHeight-r.clientWidth*r.clientHeight),e[0];const n=Array.from(document.querySelectorAll('[contenteditable="true"]')).filter(a);return n.length?(n.sort((r,o)=>o.clientWidth*o.clientHeight-r.clientWidth*r.clientHeight),n[0]):null}function v(t){return t instanceof HTMLTextAreaElement?t.value??"":t.innerText??""}function C(){const t=['button[data-testid="send-button"]','button[aria-label*="Send"]','button[aria-label*="send"]','button[type="submit"]'];for(const e of t){const n=document.querySelector(e);if(n instanceof HTMLButtonElement){const r=n.getBoundingClientRect();if(r.width>10&&r.height>10)return n}}return null}function k(t,e){const n=e.getBoundingClientRect(),r=8,o=8,i=t.offsetWidth||52,m=t.offsetHeight||28;let c=n.left+n.width/2-i/2,u=n.top-m-r;c=Math.max(o,Math.min(window.innerWidth-i-o,c)),u=Math.max(o,Math.min(window.innerHeight-m-o,u)),t.style.left=`${c}px`,t.style.top=`${u}px`}function S(t,e){const n=e==="dark"?y.dark:y.light;t.style.background=n.buttonBg,t.style.border=`1px solid ${n.border}`,t.style.color=n.text,t.style.boxShadow=n.shadow,t.style.fontFamily=n.font}let l=null,p=E(),b=location.href,d=!1,g=null;function I(){const t=document.getElementById("pp-save-btn");return t&&document.body.contains(t)?t:null}function w(){let t=I();if(!t){const e=document.getElementById("pp-save-btn");e&&e.remove(),t=document.createElement("button"),t.id="pp-save-btn",t.type="button",t.textContent="Save",t.style.cssText=`
      position: fixed;
      z-index: 999999;
      padding: 6px 10px;
      border-radius: 999px;
      cursor: pointer;
      font-size: 12px;
      line-height: 1;
      user-select: none;
      backdrop-filter: blur(10px);
      -webkit-backdrop-filter: blur(10px);
      font-family: "Open Sans", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Arial;
    `,t.addEventListener("mouseenter",()=>t.style.transform="translateY(-1px)"),t.addEventListener("mouseleave",()=>t.style.transform="translateY(0)"),t.addEventListener("click",async n=>{if(n.stopPropagation(),!l)return;const r=v(l).trim();if(!r)return;const o=await B({text:r,source:"chatgpt",url:location.href});if(o.ok){t.textContent=`Saved (${o.count}/${o.max})`,setTimeout(()=>{const i=document.getElementById("pp-save-btn");i&&(i.textContent="Save")},900);return}if(o.reason==="limit")return h("Limit reached");if(o.reason==="empty")return h("Nothing to save")}),document.body.appendChild(t)}return S(t,p),t}function A(){document.addEventListener("keydown",t=>{if(!t.altKey||!(t.ctrlKey||t.metaKey)||t.key.toLowerCase()!=="s"||t.repeat)return;const e=x();e&&(l=e);const n=t.target;if(n&&(n.tagName==="INPUT"||n.tagName==="TEXTAREA"||n.isContentEditable)&&(!e||n!==e&&!e.contains(n)))return;const r=w();r&&(t.preventDefault(),t.stopPropagation(),r.click())})}function L(){const t=['button[data-testid="stop-button"]','button[aria-label*="Stop"]','button[aria-label*="stop"]','button[title*="Stop"]','button[title*="stop"]'];for(const e of t){const n=document.querySelector(e);if(n&&a(n))return!0}return!1}function s(){d||(d=!0,requestAnimationFrame(()=>{d=!1,f()}))}function f(){if(location.href!==b){b=location.href;const o=document.getElementById("pp-save-btn");o&&o.remove()}const t=x();l=t;const e=w();if(!e)return;if(!t){e.style.display="none";return}if(!v(t).trim()){e.style.display="none";return}if(L()){e.style.display="none";return}e.style.display="block";const r=C();k(e,r??t)}function H(){T({onChange:o=>{p=o;const i=document.getElementById("pp-save-btn");i&&S(i,p)},persistToStorage:!0}),f();let t=0;const e=setInterval(()=>{f(),t++,t>=10&&clearInterval(e)},200);g=new MutationObserver(s),g.observe(document.documentElement,{childList:!0,subtree:!0}),window.addEventListener("resize",s),window.addEventListener("scroll",s,{passive:!0}),A();const n=history.pushState.bind(history),r=history.replaceState.bind(history);history.pushState=function(...o){n(...o),s()},history.replaceState=function(...o){r(...o),s()},window.addEventListener("popstate",s)}H();
