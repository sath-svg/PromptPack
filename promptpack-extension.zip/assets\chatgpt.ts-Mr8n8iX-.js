import{m as Z,s as ee,n as z,o as te,p as $}from"./theme-COKq0XYb.js";import{E as ne}from"./db-3tdwsUDZ.js";import"./api-BDkNmw7T.js";const oe=200,re=64,Y=`
  <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <path d="M9 3l1.5 4.5L15 9l-4.5 1.5L9 15l-1.5-4.5L3 9l4.5-1.5L9 3z"></path>
    <path d="M18 3l1 2.5L21.5 6l-2.5 1L18 9.5l-1-2.5L14.5 6l2.5-1L18 3z"></path>
  </svg>
`,se=`
  <svg class="pp-spin" viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true">
    <circle cx="12" cy="12" r="9" stroke-dasharray="42" stroke-dashoffset="12"></circle>
  </svg>
`;function p(e,t="success"){let n=document.getElementById("pp-toast");n||(n=document.createElement("div"),n.id="pp-toast",n.style.cssText=`
      position: absolute;
      z-index: 1000001;
      padding: 10px 12px;
      border-radius: 12px;
      color: white;
      font-size: 13px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.25);
      opacity: 0;
      transform: translateY(6px);
      transition: opacity 140ms ease, transform 140ms ease;
      font-family: "Open Sans", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Arial;
      pointer-events: none;
    `,document.body.appendChild(n)),n.style.background=t==="error"?"rgba(220, 38, 38, 0.92)":"rgba(59, 130, 246, 0.92)";const s=w();if(s){const o=s.getBoundingClientRect(),r=200,i=80;n.style.position="fixed",n.style.left=`${o.right+i}px`,n.style.top=`${o.top}px`,o.right+i+r>window.innerWidth&&(n.style.left=`${o.left-r-i}px`)}else n.style.position="fixed",n.style.right="16px",n.style.bottom="140px";n.textContent=e,n.style.opacity="1",n.style.transform="translateY(0)",window.setTimeout(()=>{n.style.opacity="0",n.style.transform="translateY(6px)"},1400)}function I(e){const t=e.getBoundingClientRect(),n=window.getComputedStyle(e);return t.width>10&&t.height>10&&n.display!=="none"&&n.visibility!=="hidden"&&n.opacity!=="0"}function w(){const e=document.querySelector("textarea#prompt-textarea");if(e&&I(e))return e;const t=o=>{let r=o.parentElement,i=0;for(;r&&i<20;){const l=r.getAttribute("role"),d=r.getAttribute("aria-modal");if(l==="dialog"||d==="true"||r.classList.contains("modal")||r.classList.contains("settings"))return!1;if(r.tagName==="FORM"){const y=r.className.toLowerCase();if(y.includes("setting")||y.includes("preference"))return!1}r=r.parentElement,i++}if(o instanceof HTMLTextAreaElement){const l=o.placeholder.toLowerCase();if(l.includes("additional behavior")||l.includes("preference")||l.includes("custom instruction"))return!1}return!0},n=Array.from(document.querySelectorAll("textarea")).filter(I).filter(t);if(n.length)return n.sort((o,r)=>r.clientWidth*r.clientHeight-o.clientWidth*o.clientHeight),n[0];const s=Array.from(document.querySelectorAll('[contenteditable="true"]')).filter(I).filter(t);return s.length?(s.sort((o,r)=>r.clientWidth*r.clientHeight-o.clientWidth*o.clientHeight),s[0]):null}function F(e){return e instanceof HTMLTextAreaElement?e.value??"":e.innerText??""}function ae(e,t){if(e instanceof HTMLTextAreaElement){const n=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value")?.set;n?n.call(e,t):e.value=t,e.dispatchEvent(new InputEvent("input",{bubbles:!0,inputType:"insertText",data:t}));return}e.textContent=t,e.dispatchEvent(new InputEvent("input",{bubbles:!0,inputType:"insertText",data:t}))}function ie(e){e.style.right=`${oe}px`,e.style.bottom=`${re}px`,e.style.left="auto",e.style.top="auto"}function ce(){if(document.getElementById("pp-enhance-styles"))return;const e=document.createElement("style");e.id="pp-enhance-styles",e.textContent=`
    @keyframes pp-spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
    .pp-spin { animation: pp-spin 0.9s linear infinite; }

    /* ChatGPT dropdown styling - light theme (dark bubble) */
    #pp-enhance-mode option {
      background: #2f2f2f !important;
      color: #ececec !important;
    }
    #pp-enhance-mode option:checked {
      background: #1a1a1a !important;
      color: #ffffff !important;
    }
    #pp-enhance-mode:focus {
      outline: 2px solid rgba(0, 0, 0, 0.14);
      outline-offset: 2px;
    }

    /* ChatGPT dropdown styling - dark theme (light bubble) */
    @media (prefers-color-scheme: dark) {
      #pp-enhance-mode option {
        background: #f7f7f8 !important;
        color: #0d0d0d !important;
      }
      #pp-enhance-mode option:checked {
        background: #ececec !important;
        color: #000000 !important;
      }
      #pp-enhance-mode:focus {
        outline: 2px solid rgba(0, 0, 0, 0.12);
        outline-offset: 2px;
      }
    }
  `,document.head.appendChild(e)}function le(e,t){const n=`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="none" stroke="${t}" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M5.5 7.5l4.5 4.5 4.5-4.5"/></svg>`;e.style.setProperty("appearance","none"),e.style.setProperty("-webkit-appearance","none"),e.style.backgroundImage=`url("data:image/svg+xml;utf8,${encodeURIComponent(n)}")`,e.style.backgroundRepeat="no-repeat",e.style.backgroundPosition="right 6px center",e.style.backgroundSize="10px 10px",e.style.paddingRight="22px"}function X(e){const t=e==="dark"?$.dark:$.light,n=document.getElementById("pp-enhance-wrap");n&&(n.style.background=t.buttonBg,n.style.border=`1px solid ${t.border}`,n.style.boxShadow=t.shadow,n.style.borderRadius="999px",n.style.fontFamily=t.font,n.style.backdropFilter="blur(10px)",n.style.webkitBackdropFilter="blur(10px)");const s=document.getElementById("pp-save-btn");s&&(s.style.background="transparent",s.style.border="none",s.style.color=t.text,s.style.fontFamily=t.font,s.style.borderRadius="999px");const o=document.getElementById("pp-enhance-btn");o&&(o.style.background="transparent",o.style.border="none",o.style.color=t.text,o.style.fontFamily=t.font,o.style.borderRadius="999px");const r=document.getElementById("pp-enhance-mode");r&&(r.style.background=t.buttonBg,r.style.border="none",r.style.color=t.text,r.style.fontFamily=t.font,le(r,t.text));const i=document.getElementById("pp-enhance-status");i&&(i.style.color=e==="dark"?"rgba(255, 255, 255, 0.9)":"rgba(17, 24, 39, 0.9)")}let E=null,x=Z(),q=location.href,R=!1,D=null,H=new Set,P="structured",O=!1,A=!1;function de(){const e=document.getElementById("pp-enhance-wrap");return e&&document.body.contains(e)?e:null}async function pe(){return chrome?.runtime?.sendMessage?new Promise(e=>{chrome.runtime.sendMessage({type:"PP_GET_ENHANCE_TOKEN"},t=>{if(chrome.runtime.lastError){e(null);return}const n=t?.token;e(typeof n=="string"?n:null)})}):null}function U(e){A=e;const t=document.getElementById("pp-save-btn"),n=document.getElementById("pp-enhance-btn"),s=!e||O;t&&(t.disabled=s,t.style.opacity=s?"0.6":"1",t.style.cursor=s?"not-allowed":"pointer"),n&&(n.disabled=s,n.style.opacity=s?"0.6":"1",n.style.cursor=s?"not-allowed":"pointer")}function G(e){O=e;const t=document.getElementById("pp-enhance-btn"),n=document.getElementById("pp-save-btn"),s=document.getElementById("pp-enhance-status"),o=document.getElementById("pp-enhance-mode");t&&(t.innerHTML=e?se:Y,t.setAttribute("aria-busy",e?"true":"false"),t.title=e?"Enhancing...":"Enhance prompt"),n&&(n.disabled=e||!A),s&&(s.textContent=e?"Enhancing...":"",s.style.display=e?"inline-flex":"none"),o&&(o.disabled=e),U(A)}async function J(){if(!E)return;const e=F(E).trim();if(!e)return p("Nothing to save","error");const t=await z({text:e,source:"chatgpt",url:location.href});if(t.ok)return p(`Saved (${t.count}/${t.max})`,"success");if(t.reason==="limit")return p("Limit reached","error");if(t.reason==="empty")return p("Nothing to save","error")}function ue(e,t){const n=document.getElementById("pp-enhance-preview");n&&n.remove();const s=document.createElement("div");s.id="pp-enhance-preview",s.style.cssText=`
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.45);
    z-index: 1000000;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20px;
  `;const o=x==="dark"?"rgba(17, 24, 39, 0.98)":"#ffffff",r=x==="dark"?"#f9fafb":"#111827",i=x==="dark"?"rgba(255, 255, 255, 0.12)":"rgba(0, 0, 0, 0.12)",l=x==="dark"?"rgba(15, 23, 42, 0.95)":"rgba(249, 250, 251, 0.98)",d=document.createElement("div");d.style.cssText=`
    background: ${o};
    color: ${r};
    border: 1px solid ${i};
    border-radius: 12px;
    width: min(900px, 100%);
    max-height: 80vh;
    display: flex;
    flex-direction: column;
    gap: 12px;
    padding: 16px;
    box-shadow: 0 24px 60px rgba(0,0,0,0.35);
  `;const y=document.createElement("div");y.textContent="Enhance preview",y.style.cssText=`
    font-size: 14px;
    font-weight: 600;
  `;const b=document.createElement("div");b.style.cssText=`
    display: flex;
    gap: 12px;
    flex: 1;
    overflow: auto;
  `,window.innerWidth<720&&(b.style.flexDirection="column");const f=(a,C)=>{const L=document.createElement("div");L.style.cssText=`
      flex: 1;
      display: flex;
      flex-direction: column;
      gap: 6px;
      min-width: 0;
    `;const M=document.createElement("div");M.textContent=a,M.style.cssText="font-size: 12px; opacity: 0.75;";const S=document.createElement("textarea");return S.readOnly=!0,S.value=C,S.style.cssText=`
      flex: 1;
      min-height: 180px;
      resize: vertical;
      background: ${l};
      color: ${r};
      border: 1px solid ${i};
      border-radius: 8px;
      padding: 10px;
      font-size: 12px;
      line-height: 1.4;
      font-family: "Open Sans", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Arial;
    `,L.appendChild(M),L.appendChild(S),L};b.appendChild(f("Before",e)),b.appendChild(f("After",t));const c=document.createElement("div");c.style.cssText=`
    display: flex;
    gap: 8px;
    justify-content: flex-end;
  `;const v=a=>{const C=document.createElement("button");return C.type="button",C.textContent=a,C.style.cssText=`
      padding: 8px 12px;
      border-radius: 8px;
      border: 1px solid ${i};
      background: ${l};
      color: ${r};
      font-size: 12px;
      cursor: pointer;
    `,C},h=v("Replace"),u=v("Save"),g=v("Cancel"),k=()=>{s.remove(),document.removeEventListener("keydown",j)},N=async()=>{try{await navigator.clipboard.writeText(t),p("Copied to clipboard","success")}catch{p("Failed to copy","error")}},j=a=>{if(a.key==="Escape"){a.preventDefault(),k();return}if((a.ctrlKey||a.metaKey)&&a.key.toLowerCase()==="c"){a.preventDefault(),a.stopPropagation(),N();return}if(a.altKey&&a.shiftKey&&a.key.toLowerCase()==="s"){a.preventDefault(),a.stopPropagation(),u.click();return}if(a.key==="Enter"&&!a.shiftKey&&!a.ctrlKey&&!a.altKey&&!a.metaKey){a.preventDefault(),a.stopPropagation(),h.click();return}},_=x==="dark"?$.dark:$.light;h.style.background=_.buttonBg,h.style.color=_.text,h.style.border="none",h.addEventListener("click",()=>{const a=w();a&&(E=a,ae(a,t),a.focus(),k(),p("Prompt replaced","success"))});const Q=chrome.runtime.getURL("img/icon-16.png");u.title="Save to PromptPack",u.setAttribute("aria-label","Save to PromptPack"),u.innerHTML=`<img src="${Q}" width="16" height="16" alt="">`,u.style.padding="6px",u.style.width="32px",u.style.height="32px",u.style.display="inline-flex",u.style.alignItems="center",u.style.justifyContent="center",u.addEventListener("click",async()=>{const a=await z({text:t,source:"chatgpt",url:location.href});if(a.ok){p(`Saved (${a.count}/${a.max})`,"success");return}if(a.reason==="limit")return p("Limit reached","error");if(a.reason==="empty")return p("Nothing to save","error");p("Failed to save","error")}),g.addEventListener("click",k),s.addEventListener("click",a=>{a.target===s&&k()}),document.addEventListener("keydown",j),c.appendChild(h),c.appendChild(u),c.appendChild(g),d.appendChild(y),d.appendChild(b),d.appendChild(c),s.appendChild(d),document.body.appendChild(s)}async function V(){if(O||!E)return;const e=F(E).trim();if(!e)return;if(e.length>6e3){p("Prompt too long to enhance. Try shortening it.","error");return}const t=await pe();if(!t){p("Sign in to use enhance feature","error");return}G(!0);try{const n={"Content-Type":"application/json",Authorization:`Bearer ${t}`},s=await fetch(ne,{method:"POST",headers:n,body:JSON.stringify({text:e,mode:P})});if(s.status===429){const r=await s.json().catch(()=>({error:""})),i=typeof r.error=="string"&&r.error.trim()?r.error:"You've hit the enhance limit. Try again later.";p(i,"error");return}if(s.status===400&&(await s.json().catch(()=>({error:""}))).error?.toLowerCase().includes("too long")){p("Prompt too long to enhance. Try shortening it.","error");return}if(!s.ok){p("Enhance failed. Try again.","error");return}const o=await s.json();if(!o.enhanced){p("Enhance failed. Try again.","error");return}ue(e,o.enhanced)}catch{p("Enhance failed. Check your connection.","error")}finally{G(!1)}}function W(){let e=de();if(!e){const t=document.getElementById("pp-enhance-wrap");t&&t.remove(),ce(),e=document.createElement("div"),e.id="pp-enhance-wrap",e.style.cssText=`
      position: fixed;
      z-index: 999999;
      display: flex;
      align-items: center;
      gap: 8px;
      padding: 8px;
      border-radius: 999px;
      user-select: none;
    `;const n=document.createElement("select");n.id="pp-enhance-mode",n.title="Enhance mode",n.style.cssText=`
      height: 32px;
      padding: 4px 12px;
      border-radius: 999px;
      font-size: 13px;
      cursor: pointer;
      outline: none;
      max-width: 130px;
    `,[{value:"structured",label:"Structured"},{value:"clarity",label:"Clarity"},{value:"concise",label:"Concise"},{value:"strict",label:"Strict"}].forEach(l=>{const d=document.createElement("option");d.value=l.value,d.textContent=l.label,n.appendChild(d)}),n.value=P,n.addEventListener("change",()=>{P=n.value});const o=document.createElement("button");o.id="pp-enhance-btn",o.type="button",o.title="Enhance prompt",o.setAttribute("aria-label","Enhance prompt"),o.style.cssText=`
      width: 32px;
      height: 32px;
      border-radius: 999px;
      padding: 0;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
    `,o.innerHTML=Y,o.addEventListener("click",l=>{l.stopPropagation(),V()});const r=document.createElement("button");r.id="pp-save-btn",r.type="button",r.title="Save prompt",r.setAttribute("aria-label","Save prompt"),r.textContent="Save",r.style.cssText=`
      height: 32px;
      padding: 0 14px;
      border-radius: 999px;
      font-size: 13px;
      line-height: 1;
      cursor: pointer;
    `,r.addEventListener("click",l=>{l.stopPropagation(),J()});const i=document.createElement("span");i.id="pp-enhance-status",i.style.cssText=`
      display: none;
      font-size: 11px;
      opacity: 0.8;
      margin-left: 4px;
      color: rgba(17, 24, 39, 0.9);
      font-family: "Open Sans", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Arial;
    `,e.appendChild(n),e.appendChild(o),e.appendChild(r),e.appendChild(i),document.body.appendChild(e)}return X(x),U(A),e}function fe(){document.addEventListener("keydown",e=>{if(!e.altKey||!e.shiftKey||e.key.toLowerCase()!=="s"||e.repeat)return;const t=w();t&&(E=t);const n=e.target;n&&(n.tagName==="INPUT"||n.tagName==="TEXTAREA"||n.isContentEditable)&&(!t||n!==t&&!t.contains(n))||(e.preventDefault(),e.stopPropagation(),J())})}function me(){document.addEventListener("keydown",e=>{if(!e.altKey||!e.shiftKey||e.key.toLowerCase()!=="e"||e.repeat)return;const t=w();t&&(E=t);const n=e.target;n&&(n.tagName==="INPUT"||n.tagName==="TEXTAREA"||n.isContentEditable)&&(!t||n!==t&&!t.contains(n))||(e.preventDefault(),e.stopPropagation(),V())})}function ye(){const e=["structured","clarity","concise","strict"];document.addEventListener("keydown",t=>{if(!t.altKey||t.shiftKey||t.ctrlKey||t.metaKey||t.repeat)return;const n=parseInt(t.key,10);if(n<1||n>4)return;const s=w();if(!s)return;const o=t.target;if(o&&(o.tagName==="INPUT"||o.tagName==="TEXTAREA"||o.isContentEditable)&&o!==s&&!s.contains(o))return;t.preventDefault(),t.stopPropagation();const r=e[n-1];P=r;const i=document.getElementById("pp-enhance-mode");i&&(i.value=r),p(`Mode: ${r.charAt(0).toUpperCase()+r.slice(1)}`,"success")})}function he(){const e=['button[data-testid="stop-button"]','button[aria-label*="Stop"]','button[aria-label*="stop"]','button[title*="Stop"]','button[title*="stop"]'];for(const t of e){const n=document.querySelector(t);if(n&&I(n))return!0}return!1}function ge(e){const t=document.createElement("button");t.className="pp-bubble-save-icon",t.type="button",t.setAttribute("aria-label","Save prompt to PromptPack"),t.title="Save to PromptPack",t.__promptText=e,t.style.cssText=`
    display: inline-flex;
    align-items: center;
    justify-content: center;
    width: 28px;
    height: 28px;
    padding: 4px;
    border-radius: 6px;
    cursor: pointer;
    transition: background-color 0.15s ease, opacity 0.15s ease;
    border: none;
    background: transparent;
    opacity: 0;
  `,t.addEventListener("mouseenter",()=>{t.style.background=x==="dark"?"rgba(255, 255, 255, 0.1)":"rgba(0, 0, 0, 0.05)",t.style.opacity="1"}),t.addEventListener("mouseleave",()=>{t.style.background="transparent"});const n=chrome.runtime.getURL("img/icon-16.png");return t.innerHTML=`<img src="${n}" width="16" height="16" alt="Save">`,t.addEventListener("click",async s=>{s.stopPropagation(),s.preventDefault();const o=s.currentTarget.__promptText;if(!o){p("No prompt to save","error");return}const r=await z({text:o,source:"chatgpt",url:location.href});r.ok?(t.style.opacity="1",p(`Saved! (${r.count}/${r.max})`,"success")):r.reason==="limit"?p("Limit reached","error"):r.reason==="empty"&&p("Nothing to save","error")}),t}function xe(){document.querySelectorAll('[data-message-author-role="user"]').forEach(t=>{if(H.has(t))return;const s=(t.querySelector("[data-message-id]")||t).textContent?.trim()||"";if(!s)return;let o=t,r=null,i=null;for(let y=0;y<10&&o;y++){const b=o.querySelector('svg use[href*="sprites-core"]');if(b){const f=b.closest("svg");if(f&&(r=f.closest("button"),r||(r=f.parentElement),r)){i=r.parentElement;break}}o=o.parentElement}if(!r||!i||i.querySelector(".pp-bubble-save-icon"))return;H.add(t);const l=ge(s);i.insertBefore(l,r);let d=t;for(let y=0;y<10&&d&&!(d.tagName==="ARTICLE"||d.getAttribute("data-message-author-role"));y++)d=d.parentElement;d&&(d.addEventListener("mouseenter",()=>{l.style.opacity="1"}),d.addEventListener("mouseleave",()=>{l.style.opacity="0"})),i.addEventListener("mouseenter",()=>{l.style.opacity="1"}),i.addEventListener("mouseleave",()=>{l.style.opacity="0"})})}function T(){R||(R=!0,requestAnimationFrame(()=>{R=!1,K()}))}function K(){if(location.href!==q){q=location.href;const o=document.getElementById("pp-enhance-wrap");o&&o.remove(),H.clear()}xe();const e=w();if(E=e,!e){const o=W();o.style.display="none";return}const t=F(e).trim(),n=W();if(U(t.length>0),he()){n.style.display="none";return}n.style.display="flex",ie(n)}function be(){ee({onChange:o=>{x=o,X(x)},persistToStorage:!0}),K();let e=0;const t=setInterval(()=>{K(),e++,e>=10&&clearInterval(t)},200);D=new MutationObserver(T),D.observe(document.documentElement,{childList:!0,subtree:!0}),window.addEventListener("resize",T),window.addEventListener("scroll",T,{passive:!0}),fe(),me(),ye();const n=history.pushState.bind(history),s=history.replaceState.bind(history);history.pushState=function(...o){n(...o),T()},history.replaceState=function(...o){s(...o),T()},window.addEventListener("popstate",T),ke()}let m=null;function ve(){const e=document.createElement("div");return e.id="pp-context-menu",e.style.cssText=`
    position: fixed;
    z-index: 999999;
    background: ${x==="dark"?"#2d2d2d":"#ffffff"};
    border: 1px solid ${x==="dark"?"#444":"#ddd"};
    border-radius: 8px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    min-width: 200px;
    max-width: 300px;
    max-height: 400px;
    overflow: hidden;
    overflow-y: auto;
    padding: 0;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
    font-size: 13px;
    display: none;
  `,document.body.appendChild(e),e}function B(){m&&(m.style.display="none")}async function Ee(e,t){m||(m=ve());const n=await te("chatgpt"),s=n.reduce((d,y)=>d+y.prompts.length,0),o=x==="dark"?{bg:"#2d2d2d",border:"#444",text:"#e5e5e5",hover:"#3d3d3d",secondary:"#999"}:{bg:"#ffffff",border:"#ddd",text:"#333",hover:"#f5f5f5",secondary:"#666"};if(m.style.background=o.bg,m.style.borderColor=o.border,m.style.color=o.text,s===0)m.innerHTML=`
      <div style="padding: 12px 16px; color: ${o.secondary}; text-align: center;">
        No saved ChatGPT prompts yet
      </div>
    `;else{const d=n.map((f,c)=>({group:f,index:c})).filter(({group:f})=>f.prompts.length>0);m.innerHTML=`
      <div style="padding: 8px 12px; font-weight: 600; border-bottom: 1px solid ${o.border}; display: flex; align-items: center; gap: 8px;">
        <img src="${chrome.runtime.getURL("img/icon-16.png")}" width="16" height="16">
        PromptPack
      </div>
      ${d.map(({group:f,index:c},v)=>{const u=v===d.length-1?"none":`1px solid ${o.border}`;return`
          <div class="pp-group" data-group-index="${c}">
            <div class="pp-group-header" data-group-index="${c}" style="
              padding: 8px 12px;
              cursor: pointer;
              border-bottom: ${u};
              font-weight: 500;
              display: flex;
              align-items: center;
              gap: 6px;
            ">
              <span class="pp-arrow" style="transition: transform 0.2s;">▶</span>
              ${f.displayName} (${f.prompts.length})
            </div>
            <div class="pp-group-items" data-group-index="${c}" style="display: none;">
              ${f.prompts.map((g,k)=>{const N=g.header?g.header:g.text.length>50?g.text.substring(0,50)+"...":g.text;return`
                <div class="pp-menu-item" data-group-index="${c}" data-prompt-index="${k}" style="
                  padding: 8px 12px 8px 28px;
                  cursor: pointer;
                  border-bottom: ${k<f.prompts.length-1?`1px solid ${o.border}`:"none"};
                  overflow: hidden;
                  text-overflow: ellipsis;
                  white-space: nowrap;
                " title="${g.text.replace(/"/g,"&quot;")}">
                  ${N}
                </div>
              `}).join("")}
            </div>
          </div>
        `}).join("")}
    `,m.querySelectorAll(".pp-group-header").forEach(f=>{const c=f;c.addEventListener("mouseenter",()=>{c.style.background=o.hover}),c.addEventListener("mouseleave",()=>{c.style.background="transparent"}),c.addEventListener("click",()=>{const v=c.dataset.groupIndex,h=m.querySelector(`.pp-group-items[data-group-index="${v}"]`),u=c.querySelector(".pp-arrow");if(h){const g=h.style.display!=="none";h.style.display=g?"none":"block",u&&(u.style.transform=g?"rotate(0deg)":"rotate(90deg)")}})}),m.querySelectorAll(".pp-menu-item").forEach(f=>{const c=f,v=parseInt(c.dataset.groupIndex||"0",10),h=parseInt(c.dataset.promptIndex||"0",10);c.addEventListener("mouseenter",()=>{c.style.background=o.hover}),c.addEventListener("mouseleave",()=>{c.style.background="transparent"}),c.addEventListener("click",()=>{const u=n[v];u&&u.prompts[h]&&(we(u.prompts[h].text),B())})})}const r={width:250,height:300};let i=e,l=t;i+r.width>window.innerWidth&&(i=window.innerWidth-r.width-10),l+r.height>window.innerHeight&&(l=window.innerHeight-r.height-10),m.style.left=`${i}px`,m.style.top=`${l}px`,m.style.display="block"}function we(e){const t=w();t&&(t instanceof HTMLTextAreaElement?(t.value=e,t.dispatchEvent(new Event("input",{bubbles:!0}))):t.isContentEditable&&(t.innerText=e,t.dispatchEvent(new Event("input",{bubbles:!0}))),t.focus())}function ke(){document.addEventListener("contextmenu",e=>{const t=e.target,n=w();n&&(t===n||n.contains(t))&&(e.preventDefault(),Ee(e.clientX,e.clientY))}),document.addEventListener("click",e=>{m&&!m.contains(e.target)&&B()}),document.addEventListener("keydown",e=>{e.key==="Escape"&&B()}),document.addEventListener("scroll",B,{passive:!0})}be();
